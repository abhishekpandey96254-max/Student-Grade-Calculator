# Student Grade Calculator (C)

A beginner-friendly console-based project written in C. It accepts a student's name, roll number, and marks in five subjects, then calculates the total, percentage, grade, and pass/fail result.

## Features
- Takes student name and roll number as input.
- Accepts marks for five subjects.
- Checks that each mark is between 0 and 100.
- Calculates total marks and percentage.
- Assigns a grade based on percentage.
- Displays PASS only if the student scores at least 33 in every subject.

## Technologies Used
- C Programming Language
- Standard Input/Output library (`stdio.h`)
- String library (`string.h`)

## How to Run

### Using GCC
1. Open a terminal in this project folder.
2. Compile the program:

   ```bash
   gcc main.c -o grade_calculator
   ```

3. Run it:

   **Windows:**
   ```bash
   grade_calculator.exe
   ```

   **Linux/macOS:**
   ```bash
   ./grade_calculator
   ```

## Grading Criteria
- A+: 90% and above
- A: 80% to below 90%
- B: 70% to below 80%
- C: 60% to below 70%
- D: 50% to below 60%
- E: Below 50%, provided all subjects are passed
- F: If marks in any subject are below 33

## Project Structure

```text
Student_Grade_Calculator/
├── main.c
└── README.md
```

## Learning Outcomes
This project demonstrates the use of variables, arrays, loops, conditional statements, input/output functions, and basic calculations in C.
