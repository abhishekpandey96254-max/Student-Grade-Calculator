#include <stdio.h>
#include <string.h>

#define SUBJECTS 5
#define MAX_MARKS 100
#define PASS_MARKS 33

int main(void)
{
    char name[50];
    int rollNumber;
    int marks[SUBJECTS];
    int total = 0;
    int i;
    float percentage;
    int allPassed = 1;

    const char *subjects[SUBJECTS] = {
        "Mathematics", "Physics", "Chemistry", "English", "Computer"
    };

    printf("====================================\n");
    printf("       STUDENT GRADE CALCULATOR\n");
    printf("====================================\n");

    printf("Enter student name: ");
    if (fgets(name, sizeof(name), stdin) == NULL) {
        printf("Error reading name.\n");
        return 1;
    }
    name[strcspn(name, "\n")] = '\0';

    printf("Enter roll number: ");
    if (scanf("%d", &rollNumber) != 1) {
        printf("Invalid roll number.\n");
        return 1;
    }

    for (i = 0; i < SUBJECTS; i++) {
        printf("Enter marks in %s (0-100): ", subjects[i]);

        if (scanf("%d", &marks[i]) != 1 ||
            marks[i] < 0 || marks[i] > MAX_MARKS) {
            printf("Invalid marks. Please enter a number from 0 to 100.\n");
            return 1;
        }

        total += marks[i];

        if (marks[i] < PASS_MARKS) {
            allPassed = 0;
        }
    }

    percentage = total / (float)SUBJECTS;

    printf("\n========== STUDENT RESULT ==========\n");
    printf("Name       : %s\n", name);
    printf("Roll No.   : %d\n", rollNumber);

    for (i = 0; i < SUBJECTS; i++) {
        printf("%-12s: %d/%d\n", subjects[i], marks[i], MAX_MARKS);
    }

    printf("------------------------------------\n");
    printf("Total      : %d/%d\n", total, SUBJECTS * MAX_MARKS);
    printf("Percentage : %.2f%%\n", percentage);

    if (!allPassed) {
        printf("Grade      : F\n");
        printf("Result     : FAIL (Below pass marks in at least one subject)\n");
    } else {
        if (percentage >= 90) {
            printf("Grade      : A+\n");
        } else if (percentage >= 80) {
            printf("Grade      : A\n");
        } else if (percentage >= 70) {
            printf("Grade      : B\n");
        } else if (percentage >= 60) {
            printf("Grade      : C\n");
        } else if (percentage >= 50) {
            printf("Grade      : D\n");
        } else {
            printf("Grade      : E\n");
        }

        printf("Result     : PASS\n");
    }

    printf("====================================\n");
    return 0;
}
